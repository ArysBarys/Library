<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Проверяем, какая дисциплина выбрана
$course_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Получаем информацию о дисциплине
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

// Получаем книги этой дисциплины
$stmt = $pdo->prepare("SELECT * FROM books WHERE course_id = ? ORDER BY created_at DESC");
$stmt->execute([$course_id]);
$books = $stmt->fetchAll();

$saved_ids = [];
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT book_id FROM saved_books WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $saved_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($course['name'] ?? 'Дисциплина') ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/script.js" defer></script>
</head>
<body>
<?php require_once 'includes/header.php'; ?>

<main>
    <h2><?= htmlspecialchars($course['name'] ?? 'Дисциплина') ?></h2>

    <?php if ($books): ?>
        <div class="books">
            <?php foreach($books as $book): ?>
                <div class="book-card">
                    <div class="book-info">
                        <h3><?= htmlspecialchars($book['title']) ?></h3>
                        <p class="author">👤 <?= htmlspecialchars($book['author']) ?></p>
                        <p><?= nl2br(htmlspecialchars($book['description'])) ?></p>
                    </div>

                    <div class="book-actions">
                        <?php if (!empty($book['pdf_path'])): ?>
                            <a href="admin/uploads/<?= htmlspecialchars($book['pdf_path']) ?>" target="_blank" class="read-btn">📖 Читать PDF</a>
                        <?php endif; ?>

                        <?php if (isset($_SESSION['user_id'])): ?>
                            <?php if (in_array($book['id'], $saved_ids)): ?>
                                <button class="save-btn disabled" disabled>✔️ Сохранено</button>
                            <?php else: ?>
                                <form method="POST" action="save_book.php" style="display:inline;">
                                    <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                    <button type="submit" class="save-btn">⭐ Сохранить</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Пока книг нет.</p>
    <?php endif; ?>
</main>

<?php require_once 'includes/footer.php'; ?>
</body>
</html>