<?php
// ajax_search.php
require_once 'includes/db.php';

$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$results = [];

if ($keyword !== '') {
    $like = "%$keyword%";

    // Ищем дисциплины
    $stmt = $pdo->prepare("SELECT id, name, description, 'course' AS type FROM courses WHERE name LIKE ? OR description LIKE ? LIMIT 5");
    $stmt->execute([$like, $like]);
    $courses = $stmt->fetchAll();

    // Ищем книги
    $stmt = $pdo->prepare("SELECT b.id, b.title, b.author, b.description, b.pdf_path, c.name as course_name, 'book' AS type 
                           FROM books b 
                           JOIN courses c ON b.course_id = c.id 
                           WHERE b.title LIKE ? OR b.author LIKE ? LIMIT 5");
    $stmt->execute([$like, $like]);
    $books = $stmt->fetchAll();

    $results = array_merge($courses, $books);
}

header('Content-Type: application/json');
echo json_encode($results);