document.addEventListener("DOMContentLoaded", function () {
    /**
     * ==========================================
     * 1. ПЕРЕКЛЮЧЕНИЕ ТЕМЫ (Светлая / Темная)
     * ==========================================
     */
    const themeToggle = document.getElementById("theme-toggle");
    
    // Проверяем сохраненную тему в браузере
    if (localStorage.getItem("theme") === "dark") {
        document.body.classList.add("dark-theme");
        if (themeToggle) themeToggle.textContent = "☀️ Светлая тема";
    }

    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            document.body.classList.toggle("dark-theme");
            const isDark = document.body.classList.contains("dark-theme");
            localStorage.setItem("theme", isDark ? "dark" : "light");
            themeToggle.textContent = isDark ? "☀️ Светлая тема" : "🌙 Тёмная тема";
        });
    }

    /**
     * ==========================================
     * 2. ПОДТВЕРЖДЕНИЕ ВЫХОДА
     * ==========================================
     */
    const logoutLinks = document.querySelectorAll('a[href*="logout.php"]');
    logoutLinks.forEach(link => {
        link.addEventListener("click", function (e) {
            if (!confirm("Вы уверены, что хотите выйти из системы?")) {
                e.preventDefault();
            }
        });
    });

    /**
     * ==========================================
     * 3. УМНЫЙ AJAX ПОИСК (с задержкой)
     * ==========================================
     */
    const searchBox = document.getElementById("search-box");
    const resultsDiv = document.getElementById("search-results");
    let searchTimeout;

    if (searchBox && resultsDiv) {
        searchBox.addEventListener("input", function () {
            clearTimeout(searchTimeout);
            const query = this.value.trim();

            if (query.length < 2) {
                resultsDiv.innerHTML = "";
                resultsDiv.style.display = "none";
                return;
            }

            // Устанавливаем задержку 300мс, чтобы не спамить базу данных
            searchTimeout = setTimeout(() => {
                fetch(`ajax_search.php?q=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(data => {
                        renderResults(data, query);
                    })
                    .catch(error => console.error("Ошибка поиска:", error));
            }, 300);
        });
    }

    /**
     * Функция рендеринга результатов поиска
     */
    function renderResults(data, query) {
        resultsDiv.innerHTML = "";
        resultsDiv.style.display = "block";

        if (data.length === 0) {
            resultsDiv.innerHTML = "<p class='no-results'>Ничего не найдено по вашему запросу.</p>";
            return;
        }

        const regex = new RegExp(`(${query})`, "gi");

        data.forEach((item, index) => {
            const card = document.createElement("div");
            const isCourse = (item.type === 'course');
            
            card.className = isCourse ? "course-card search-fade" : "book-card search-fade";
            
            // Подсвечиваем совпадения тегом <mark>
            const titleText = isCourse ? item.name : item.title;
            const highlightedTitle = titleText.replace(regex, `<mark>$1</mark>`);
            const highlightedDesc = item.description.substring(0, 120).replace(regex, `<mark>$1</mark>`);

            const link = isCourse ? `discipline.php?id=${item.id}` : '#';

            card.innerHTML = `
                <div class="card-content">
                    <span class="badge">${isCourse ? '📚 Дисциплина' : '📖 Книга'}</span>
                    <h3><a href="${link}">${highlightedTitle}</a></h3>
                    <p>${highlightedDesc}...</p>
                    ${!isCourse && item.author ? `<small>Автор: ${item.author.replace(regex, `<mark>$1</mark>`)}</small>` : ''}
                </div>
            `;

            resultsDiv.appendChild(card);

            // Плавное каскадное появление
            setTimeout(() => {
                card.style.opacity = "1";
                card.style.transform = "translateY(0)";
            }, index * 50);
        });
    }

    /**
     * ==========================================
     * 4. АНИМАЦИЯ КНОПОК
     * ==========================================
     */
    const buttons = document.querySelectorAll("button, .save-btn, .read-btn");
    buttons.forEach(button => {
        button.addEventListener("mousedown", () => button.style.transform = "scale(0.95)");
        button.addEventListener("mouseup", () => button.style.transform = "scale(1)");
    });
});