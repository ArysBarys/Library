<?php
require_once 'includes/auth.php';
checkAuth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_id = intval($_POST['book_id']);
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare("DELETE FROM saved_books WHERE user_id = ? AND book_id = ?");
    $stmt->execute([$user_id, $book_id]);
}

header("Location: dashboard.php");
exit;