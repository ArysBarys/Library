<?php
require_once __DIR__ . '/includes/auth_admin.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

$csrf_token = generateCSRFToken();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCSRFToken($_POST['csrf_token']);

    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $course_id = intval($_POST['course_id']);
    $description = trim($_POST['description']);
    $pdf_name = null;

    if (!empty($_FILES['pdf_file']['name'])) {
        $target_dir = __DIR__ . "/uploads/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

        $pdf_name = bin2hex(random_bytes(10)) . '.pdf';
        if (!move_uploaded_file($_FILES['pdf_file']['tmp_name'], $target_dir . $pdf_name)) {
            $error = "Ошибка загрузки файла.";
        }
    }

    if (!$error) {
        $stmt = $pdo->prepare("INSERT INTO books (title, author, course_id, description, pdf_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $author, $course_id, $description, $pdf_name]);
        header("Location: books.php");
        exit;
    }
}

$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавить книгу | AI Админ</title>
    <link rel="stylesheet" href="<?= site_url('assets/css/style.css') ?>">
    <script src="/assets/js/script.js" defer></script>
</head>
<body>
<?php require_once '../includes/header.php'; ?>

<main class="dashboard">
    <h2>➕ Добавить книгу</h2>
    <form method="POST" enctype="multipart/form-data" class="admin-form">
        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
        
        <label>Файл (PDF):</label>
        <input type="file" name="pdf_file" accept=".pdf" required id="pdf_input">
        
        <button type="button" id="ai-btn" onclick="analyzeFile()">✨ Заполнить с помощью ИИ</button>

        <label>Название:</label>
        <input type="text" name="title" required>

        <label>Автор:</label>
        <input type="text" name="author" required>

        <label>Дисциплина:</label>
        <select name="course_id">
            <?php foreach ($courses as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Описание:</label>
        <textarea name="description" rows="4"></textarea>

        <button type="submit" class="save-btn">Сохранить книгу</button>
    </form>
</main>

<script>
async function analyzeFile() {
    const fileInput = document.getElementById('pdf_input');
    const btn = document.getElementById('ai-btn');
    if (!fileInput.files[0]) return alert("Выберите файл!");

    btn.textContent = "⌛ Думаю...";
    btn.disabled = true;

    const formData = new FormData();
    formData.append('pdf_file', fileInput.files[0]);

    try {
        const response = await fetch('ai_analyze.php', { method: 'POST', body: formData });
        const rawData = await response.json();

        if (rawData.error) {
            throw new Error(rawData.error.message || "Ошибка API");
        }

        // Извлекаем текст из структуры Gemini
        let textResult = rawData.candidates[0].content.parts[0].text;
        
        // Очистка: находим первый '{' и последний '}' на случай, если ИИ добавил текст вокруг
        const start = textResult.indexOf('{');
        const end = textResult.lastIndexOf('}') + 1;
        const jsonStr = textResult.substring(start, end);
        
        const finalData = JSON.parse(jsonStr);

        // Заполняем поля
        document.querySelector('input[name="title"]').value = finalData.title || '';
        document.querySelector('input[name="author"]').value = finalData.author || '';
        document.querySelector('textarea[name="description"]').value = finalData.description || '';
        
        btn.textContent = "✨ Готово!";
    } catch (e) {
        console.error("Full Error:", e);
        alert("Ошибка: " + e.message);
        btn.textContent = "❌ Ошибка";
    } finally {
        btn.disabled = false;
    }
}
</script>
</body>
</html>