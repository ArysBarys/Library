<?php
require_once __DIR__ . '/includes/auth_admin.php';
header('Content-Type: application/json');

// ТВОЙ КЛЮЧ
$apiKey = "AIzaSyBG2s91cjGhliovpnMp8hKIh1mufNiig0I"; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['pdf_file'])) {
    $pdfData = base64_encode(file_get_contents($_FILES['pdf_file']['tmp_name']));

    $payload = [
        "contents" => [[
            "parts" => [
                ["text" => "Extract: title, author, and brief description from this PDF. Return ONLY JSON: {\"title\": \"...\", \"author\": \"...\", \"description\": \"...\"}"],
                ["inline_data" => ["mime_type" => "application/pdf", "data" => $pdfData]]
            ]
        ]],
        "generationConfig" => [
            "response_mime_type" => "application/json"
        ]
    ];

    // ИСПОЛЬЗУЕМ МОДЕЛЬ ИЗ ТВОЕГО СПИСКА
    $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=" . $apiKey;

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if ($httpCode !== 200) {
        http_response_code($httpCode);
    }
    
    echo $response;
    exit;
}