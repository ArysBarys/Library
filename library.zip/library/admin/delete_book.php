<?php
require_once __DIR__ . '/includes/auth_admin.php';
require_once __DIR__ . '/../includes/db.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Сначала находим имя файла
$stmt = $pdo->prepare("SELECT pdf_path FROM books WHERE id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch();

if ($book) {
    // Удаляем файл с диска
    if ($book['pdf_path']) {
        $file_path = __DIR__ . "/uploads/" . $book['pdf_path'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }
    // Удаляем запись из БД
    $stmt = $pdo->prepare("DELETE FROM books WHERE id = ?");
    $stmt->execute([$id]);
}

header("Location: books.php");
exit;