<?php
require_once __DIR__ . '/includes/auth_admin.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$success = '';

// Получаем данные книги
$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$book_id]);
$book = $stmt->fetch();

if (!$book) {
    die("Книга не найдена.");
}

// Получаем список дисциплин для выпадающего списка
$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'])) die("CSRF Error");

    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $course_id = intval($_POST['course_id']);
    $description = trim($_POST['description']);
    $pdf_name = $book['pdf_path']; // По умолчанию оставляем старый файл

    // Если загружен новый файл
    if (!empty($_FILES['pdf_file']['name'])) {
        $target_dir = __DIR__ . "/uploads/";
        $file_ext = strtolower(pathinfo($_FILES['pdf_file']['name'], PATHINFO_EXTENSION));

        if ($file_ext !== 'pdf') {
            $error = "Только PDF!";
        } else {
            // Удаляем старый файл, если он существует
            if ($book['pdf_path'] && file_exists($target_dir . $book['pdf_path'])) {
                unlink($target_dir . $book['pdf_path']);
            }
            // Сохраняем новый
            $pdf_name = bin2hex(random_bytes(10)) . '.pdf';
            move_uploaded_file($_FILES['pdf_file']['tmp_name'], $target_dir . $pdf_name);
        }
    }

    if (!$error) {
        $stmt = $pdo->prepare("UPDATE books SET title = ?, author = ?, course_id = ?, description = ?, pdf_path = ? WHERE id = ?");
        $stmt->execute([$title, $author, $course_id, $description, $pdf_name, $book_id]);
        header("Location: books.php?updated=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактировать: <?= htmlspecialchars($book['title']) ?></title>
    <link rel="stylesheet" href="<?= site_url('assets/css/style.css') ?>">
    <script src="/assets/js/script.js" defer></script>
</head>
<body>
<?php require_once '../includes/header.php'; ?>

<main class="dashboard">
    <h2>✏️ Редактирование книги</h2>
    <form method="POST" enctype="multipart/form-data" class="admin-form">
        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

        <label>Название:</label>
        <input type="text" name="title" value="<?= htmlspecialchars($book['title']) ?>" required>

        <label>Автор:</label>
        <input type="text" name="author" value="<?= htmlspecialchars($book['author']) ?>" required>

        <label>Дисциплина:</label>
        <select name="course_id">
            <?php foreach ($courses as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $c['id'] == $book['course_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Описание:</label>
        <textarea name="description" rows="5"><?= htmlspecialchars($book['description']) ?></textarea>

        <label>Заменить PDF (оставьте пустым, чтобы не менять):</label>
        <input type="file" name="pdf_file" accept=".pdf">
        
        <div style="margin-top: 20px;">
            <button type="submit" class="save-btn">💾 Сохранить изменения</button>
            <a href="books.php" class="read-btn" style="background:#666;">Отмена</a>
        </div>
    </form>
</main>
</body>
</html>