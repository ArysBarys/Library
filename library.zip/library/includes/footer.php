<footer>
    <p>© 2026 AI-library КазУТБ</p>
</footer>