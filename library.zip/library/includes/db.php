<?php
//MYarchlinux
//$host = 'localhost';
//$db   = 'library_db';
//$user = 'root';
//$pass = 'sadpuppy228';

//Windows импорт
$host   = 'localhost';
$dbname = 'library_db';
$user   = 'root';
$pass   = '';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}


$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4" 
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    error_log("DB connection error: " . $e->getMessage());
    die("Ошибка подключения к базе данных.");
}

// Глобальная функция путей
if (!function_exists('site_url')) {
    function site_url($path = '') {
        $script_name = $_SERVER['SCRIPT_NAME'];
        $root = str_replace('\\', '/', dirname($script_name));
        $root = preg_replace('/(\/admin|\/auth)$/', '', $root);
        return rtrim($root, '/') . '/' . ltrim($path, '/');
    }
}
?>