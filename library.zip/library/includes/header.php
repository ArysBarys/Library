<?php
// includes/header.php
require_once __DIR__ . '/auth.php';
$user = getUser($pdo);

// Проверка роли админа
$isAdmin = ($user && isset($user['role']) && $user['role'] === 'admin');

// Функция для динамических путей (если она еще не объявлена)
if (!function_exists('site_url')) {
    function site_url($path) {
        $root = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
        $root = rtrim($root, '/auth'); // очистка, если вызвано из вложенных папок
        $root = rtrim($root, '/admin');
        return '/' . ltrim($path, '/');
    }
}
?>
<header>
    <h1><a href="<?= site_url('index.php') ?>" style="color:inherit; text-decoration:none;">AI-library КазУТБ</a></h1>
    <nav>
        <a href="<?= site_url('index.php') ?>">Главная</a>
        <?php if ($user): ?>
            <a href="<?= site_url('dashboard.php') ?>">Мои книги</a>
            <?php if ($isAdmin): ?>
                <a href="<?= site_url('admin/index.php') ?>" style="color:#ffd700; font-weight:bold;">👑 Админ</a>
            <?php endif; ?>
            <a href="<?= site_url('auth/logout.php') ?>" id="logout-btn">Выйти</a>
        <?php else: ?>
            <a href="<?= site_url('auth/login.php') ?>">Войти</a>
            <a href="<?= site_url('auth/register.php') ?>">Регистрация</a>
        <?php endif; ?>
        <button id="theme-toggle">🌙 Тема</button>
    </nav>
</header>