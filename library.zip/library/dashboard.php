<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
checkAuth();

$user = getUser($pdo);
$stmt = $pdo->prepare("
    SELECT b.*, c.name as course_name 
    FROM saved_books sb
    JOIN books b ON sb.book_id = b.id
    JOIN courses c ON b.course_id = c.id
    WHERE sb.user_id = ?
");
$stmt->execute([$user['id']]);
$books = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мой кабинет</title>
    <link rel="stylesheet" href="<?= site_url('assets/css/style.css') ?>">
    <script src="/assets/js/script.js" defer></script>
</head>
<body>
<?php require_once 'includes/header.php'; ?>

<main class="dashboard-container">
    <div class="profile-card">
        <h2>👋 Привет, <?= htmlspecialchars($user['username']) ?></h2>
        <p>Ваш уровень доступа: <strong><?= $user['role'] ?></strong></p>
    </div>

    <h3>⭐ Сохраненные книги</h3>
    <div class="books-grid">
        <?php foreach ($books as $book): ?>
            <div class="book-card">
                <span class="badge"><?= htmlspecialchars($book['course_name']) ?></span>
                <h4><?= htmlspecialchars($book['title']) ?></h4>
                <div class="card-actions">
                    <a href="admin/uploads/<?= $book['pdf_path'] ?>" target="_blank" class="read-btn">Читать</a>
                    <form method="POST" action="remove_book.php" style="display:inline;">
                        <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                        <button type="submit" class="delete-btn">🗑️</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>
</body>
</html>